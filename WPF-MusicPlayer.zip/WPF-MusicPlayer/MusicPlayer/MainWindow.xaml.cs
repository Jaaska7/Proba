﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using MaterialDesignThemes.Wpf;
using TagLib;
using MusicPlayer;
using System.Collections;

namespace Atena
{
    public partial class MainWindow : Window
    {
        private string playlistNombre;
        private MediaPlayer media;
        private TimeSpan _position;
        private readonly DispatcherTimer _timer = new DispatcherTimer();
        private readonly string[] json = new string[400];
        private int queue = 0;
        private int playlist = 0;
        private string titl = "Please Choose a Music to Start";
        private int pointer = 0;

        public MainWindow()
        {
            InitializeComponent();
            InitializeMediaPlayer();
            InitializeTimer();
        }

        private void InitializeMediaPlayer()
        {
            media = new MediaPlayer();
            media.MediaFailed += (o, args) => MessageBox.Show("Media Failed!!");
            media.MediaOpened += Media_MediaOpened;
            media.MediaEnded += Media_MediaEnded;
        }

        private void InitializeTimer()
        {
            _timer.Interval = TimeSpan.FromMilliseconds(1000);
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

        private void Media_MediaOpened(object sender, EventArgs args)
        {
            media.Position = new TimeSpan(0, 0, 0, 0);
            var tagFile = TagLib.File.Create(json[queue]);

            Title.Text = tagFile.Tag.Title;
            Author.Text = tagFile.Tag.FirstArtist;
            titl = tagFile.Tag.Title;

            var firstPicture = tagFile.Tag.Pictures.FirstOrDefault();
            if (firstPicture != null)
            {
                MemoryStream ms = new MemoryStream(firstPicture.Data.Data);
                ms.Seek(0, SeekOrigin.Begin);
            }

            pointer = 0;
            _position = media.NaturalDuration.TimeSpan;
            sliderSeek.Minimum = 0;
            sliderSeek.Maximum = _position.TotalSeconds;
        }

        private void Media_MediaEnded(object sender, EventArgs args)
        {
            if (queue < playlist)
                queue++;
            else
                queue = 0;

            media.Open(new Uri(json[queue], UriKind.RelativeOrAbsolute));
            PlayIcon.Kind = PackIconKind.Pause;
            Play.Click -= Play_Click;
            Play.Click += Pause_Click;
            sliderSeek.Value = 0;
            media.Play();
        }

        private void Timer_Tick(object sender, EventArgs args)
        {
            sliderSeek.Value = media.Position.TotalSeconds;

            if (!string.IsNullOrEmpty(titl) && titl.Length > 40)
            {
                if (pointer + 39 < titl.Length)
                {
                    Title.Text = titl.Substring(pointer, 40);
                    pointer++;
                }
                else
                {
                    pointer = 0;
                }
            }
        }

        private void Play_Click(object sender, RoutedEventArgs e)
        {
            PlayIcon.Kind = PackIconKind.Pause;
            Play.Click -= Play_Click;
            Play.Click += Pause_Click;
            media.Play();
        }

        private void Pre_Click(object sender, RoutedEventArgs e)
        {
            sliderSeek.Value = 0;
            if (sliderSeek.Value < 10)
            {
                if (queue - 1 >= 0)
                {
                    queue--;
                }
                else
                {
                    queue = 0;
                }
                media.Open(new Uri(json[queue], UriKind.RelativeOrAbsolute));
                PlayIcon.Kind = PackIconKind.Pause;
                Play.Click -= Play_Click;
                Play.Click += Pause_Click;
                media.Play();
            }
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            sliderSeek.Value = 0;
            if (queue + 1 < playlist)
            {
                queue++;
            }
            else
            {
                queue = 0;
            }
            media.Open(new Uri(json[queue], UriKind.RelativeOrAbsolute));
            PlayIcon.Kind = PackIconKind.Pause;
            Play.Click -= Play_Click;
            Play.Click += Pause_Click;
            media.Play();
        }

        private void Pause_Click(object sender, RoutedEventArgs e)
        {
            PlayIcon.Kind = PackIconKind.Play;
            Play.Click += Play_Click;
            Play.Click -= Pause_Click;
            media.Pause();
        }

        private void MusicMoved(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (Math.Abs(media.Position.TotalSeconds - sliderSeek.Value) > 2)
            {
                media.Position = new TimeSpan(0, 0, 0, Convert.ToInt32(sliderSeek.Value));
            }
        }


        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog
            {
                DefaultExt = ".mp3",
                CheckFileExists = true,
                Filter = "MP3 Files (*.mp3)|*.mp3"
            };

            if (dlg.ShowDialog() == true)
            {
                string folderPath = new FileInfo(dlg.FileName).DirectoryName;
                string[] files = Directory.GetFiles(folderPath, "*.mp3");

                llistacansons.ItemsSource = files.Select(file => new FileInfo(file).Name);

                string filename = dlg.FileName;
                int i = 0;
                playlist = 0;
                foreach (string file in files)
                {
                    if (file == filename)
                    {
                        queue = i;
                    }
                    json[i] = file;
                    i++;
                    playlist++;
                }
                media.Open(new Uri(json[queue], UriKind.RelativeOrAbsolute));
                PlayIcon.Kind = PackIconKind.Pause;
                Play.Click -= Play_Click;
                Play.Click += Pause_Click;
                media.Play();
            }
        }

        private void AgregarCancion_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Añadir cancion a la playlist");
            string nuevoTexto = txtNewSong.Text;
            ListBoxItem nuevoItem = new ListBoxItem
            {
                Content = new StackPanel() { Orientation = Orientation.Horizontal }
            };

            Button eliminarBoton = new Button
            {
                Content = "Eliminar"
            };

            eliminarBoton.Click += (s, args) => listBoxPlayedSongs.Items.Remove(nuevoItem);

            Button abrirBoton = new Button
            {
                Content = "Obrir"
            };

            abrirBoton.Click += (s, args) => AbrirCancionVentana( playlistNombre);

            ((StackPanel)nuevoItem.Content).Children.Add(new TextBlock() { Text = nuevoTexto });
            ((StackPanel)nuevoItem.Content).Children.Add(eliminarBoton);
            ((StackPanel)nuevoItem.Content).Children.Add(abrirBoton);

            listBoxPlayedSongs.Items.Add(nuevoItem);
            txtNewSong.Text = string.Empty;
        }

        private void AbrirCancionVentana(string nombrePlaylist)
        {
            NuevaVentana nuevaVentana = new NuevaVentana();
            var selectedItems = listBoxPlayedSongs.SelectedItems;
            nuevaVentana.ActualizarListView(selectedItems, nombrePlaylist);

            nuevaVentana.Show();
        }


        private void Llistacansons_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (llistacansons.SelectedItem != null)
            {
                string selectedSong = llistacansons.SelectedItem.ToString();
                int index = Array.FindIndex(json, song => song != null && song.EndsWith(selectedSong));

                if (index != -1)
                {
                    queue = index;
                    media.Open(new Uri(json[queue], UriKind.RelativeOrAbsolute));
                    PlayIcon.Kind = PackIconKind.Pause;
                    Play.Click -= Play_Click;
                    Play.Click += Pause_Click;
                    media.Play();
                }
            }
        }
    }
}
