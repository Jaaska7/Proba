# WPF Music Player
Preview
<img src="./Preview.png"/><br>
----------------
A Simple Music Player for Windows made with C# and WPF<br><br>
Just goto <a href="https://github.com/dev-mkm/WPF-MusicPlayer/releases/tag/Music-Player">Releases</a> and download the suitable version.<br><br>
Then Open it and click on "Open Folder" then select a music file in the folder you want and Enjoy<br><br>
----------------

Feel Free to use This project
